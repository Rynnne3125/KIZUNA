Set WshShell = WScript.CreateObject("WScript.Shell")
strDesktop = WshShell.SpecialFolders("Desktop")
Set oLink = WshShell.CreateShortcut(strDesktop & "\KIZUNA - H?c Ti?ng Nh?t.lnk")

Set fso = CreateObject("Scripting.FileSystemObject")
strCurrentPath = fso.GetParentFolderName(WScript.ScriptFullName)

oLink.TargetPath = strCurrentPath & "\KIZUNA-Desktop.bat"
oLink.WorkingDirectory = strCurrentPath
oLink.Description = "KIZUNA - H?c Ti?ng Nh?t Th?c Chi?n"
oLink.WindowStyle = 7
oLink.Save

MsgBox "?? t?o bi?u t??ng KIZUNA tr?n m?n h?nh Desktop th?nh c?ng!" & vbCrLf & "B?y gi? b?n c? th? m? KIZUNA t? m?n h?nh m?y t?nh.", 64, "KIZUNA PC App"