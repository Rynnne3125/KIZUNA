﻿===================================================================
      KIZUNA PC DESKTOP APP - HƯỚNG DẪN CÀI ĐẶT & SỬ DỤNG
===================================================================

1. GIỚI THIỆU:
   KIZUNA PC App cho phép bạn học tiếng Nhật trong cửa sổ độc lập,
   không có thanh địa chỉ trình duyệt, hỗ trợ phím tắt Space (lật thẻ),
   mũi tên chuyển câu và tốc độ mở tức thì.

2. CÁCH DÙNG:
   - Cách 1: Nhấp đúp vào 'Cai-Dat-Phim-Tat.bat' để tạo biểu tượng KIZUNA ngay trên Desktop.
   - Cách 2: Nhấp đúp vào 'KIZUNA-Desktop.bat' để mở ứng dụng ngay lập tức.
   - Cách 3: Mở trình duyệt Chrome/Edge trên máy tính và bấm 'Cài đặt KIZUNA' (PWA).

Chúc bạn chinh phục tiếng Nhật thành công cùng KIZUNA!
===================================================================