@echo off
cscript //nologo "%~dp0Install-Desktop-Shortcut.vbs"