﻿@echo off
chcp 65001 >nul
title KIZUNA - Học Tiếng Nhật
echo Đang khởi động KIZUNA Desktop App...

set KIZUNA_URL=https://kizuna-thanhphongit.duckdns.org

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=%KIZUNA_URL%
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app=%KIZUNA_URL%
    exit /b
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=%KIZUNA_URL%
    exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=%KIZUNA_URL%
    exit /b
)

start "" "%KIZUNA_URL%"